#include <stdio.h>

int main()
{
	printf("Salve, Mondo!\n\n\n\n");
	return 0;
}
